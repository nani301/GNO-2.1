import BestInstituteSection from '../BestInstituteSection';

export default function BestInstituteSectionExample() {
  return <BestInstituteSection />;
}
