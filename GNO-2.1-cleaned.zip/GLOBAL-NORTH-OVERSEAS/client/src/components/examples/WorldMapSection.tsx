import WorldMapSection from '../WorldMapSection';

export default function WorldMapSectionExample() {
  return <WorldMapSection />;
}
