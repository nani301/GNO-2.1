import Gallery from '../Gallery';

export default function GalleryExample() {
  return <Gallery />;
}
