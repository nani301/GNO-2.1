import StatsCounter from '../StatsCounter';

export default function StatsCounterExample() {
  return <StatsCounter />;
}
