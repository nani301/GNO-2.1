import PartnerLogos from '../PartnerLogos';

export default function PartnerLogosExample() {
  return <PartnerLogos />;
}
